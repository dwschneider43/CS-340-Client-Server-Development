# crud.py
"""
CRUD class for interacting with the Grazioso Salvare MongoDB database.
"""

from typing import List, Dict, Any, Optional
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from bson import ObjectId


class AnimalShelter:
    """
    AnimalShelter provides CRUD operations for a MongoDB collection.
    """

    def __init__(
        self,
        username: str = None,
        password: str = None,
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "aac",
        collection_name: str = "animals"
    ) -> None:
        """
        Initialize connection to MongoDB WITHOUT authentication.
        """
        if username and password:
            uri = f"mongodb://{username}:{password}@{host}:{port}"
            self.client = MongoClient(uri)
        else:
            self.client = MongoClient(host=host, port=port)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def create(self, data: Dict[str, Any]) -> bool:
        """
        Insert a single document into the collection.
        """
        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError:
            return False

    def _serialize(self, doc: Any) -> Any:
        if isinstance(doc, dict):
            out = {}
            for k, v in doc.items():
                out[k] = self._serialize(v)
            return out
        if isinstance(doc, list):
            return [self._serialize(v) for v in doc]
        if isinstance(doc, tuple):
            return tuple(self._serialize(v) for v in doc)
        if isinstance(doc, ObjectId):
            return str(doc)
        return doc

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Query for document(s) from the collection.
        """
        if query is None:
            query = {}

        try:
            cursor = self.collection.find(query, projection)
            return [self._serialize(d) for d in cursor]
        except PyMongoError:
            return []

    def update(
        self,
        query: Dict[str, Any],
        new_values: Dict[str, Any],
        many: bool = False
    ) -> int:
        """
        Update document(s) in the collection.
        """
        if not query or not new_values:
            return 0

        try:
            update_doc = {"$set": new_values}
            if many:
                result = self.collection.update_many(query, update_doc)
            else:
                result = self.collection.update_one(query, update_doc)
            return result.modified_count
        except PyMongoError:
            return 0

    def delete(self, query: Dict[str, Any], many: bool = False) -> int:
        """
        Delete document(s) from the collection.
        """
        if not query:
            return 0

        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return result.deleted_count
        except PyMongoError:
            return 0